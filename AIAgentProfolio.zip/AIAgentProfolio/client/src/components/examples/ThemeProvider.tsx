import { ThemeProvider } from '../ThemeProvider'

export default function ThemeProviderExample() {
  return (
    <ThemeProvider>
      <div className="p-4">
        <h3>Theme Provider Example</h3>
        <p>This component provides theme context to the entire app.</p>
      </div>
    </ThemeProvider>
  )
}