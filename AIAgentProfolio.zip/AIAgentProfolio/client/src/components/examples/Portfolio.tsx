import Portfolio from '../Portfolio'

export default function PortfolioExample() {
  return <Portfolio />
}