import Header from '../Header'
import { ThemeProvider } from '../ThemeProvider'

export default function HeaderExample() {
  return (
    <ThemeProvider>
      <Header />
      <div className="pt-16 p-4">
        <h3>Header Component</h3>
        <p>Navigation header with theme toggle and mobile menu</p>
      </div>
    </ThemeProvider>
  )
}